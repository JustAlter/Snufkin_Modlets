Unpack to "C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die\Mods" or your corresponding installation folder.

All plushies but Mousey's are blocks. Ironmouse's is a holdable item. With LMB it talks (20+ voice clips). With RMB you place it on the ground.
The posters are blocks, most occupy 1 block except Poster06, who covers a block to to the right.

TODO:
-Make the voice clips sound like they come from a speaker (a few already sound like that).
-Add shoulder companions.
-Add plushies and flags of more Vtubers.
-Sleep.

------------------------
New blocks:
-Flag Bunny Brigade
-Flag Precious Family
-OGTexas Plushie
-Bunny_gif Plushie
-Silvervale Plushie
-Zentreya Plushie
-ProjektMelody Plushie
-imo_plushie_block (non craftable)

-Poster01 - 06

New items:
-Ironmouse Plushie


Art Credit:
-Ironmouse Poster: https://www.instagram.com/pomme_lapin
-ProjektMelody Poster: https://dakimakuri.com/artists/katzchen
-Silvervale Poster: https://twitter.com/Matilda_Fiship